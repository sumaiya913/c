#include<stdio.h>
int main()
{
    int num1,num2,sum;
   FILE *fptr;
fptr =fopen("d:\\program.txt","w");

printf("Enter num: ");
scanf("%d %d",&num1,&num2);
sum=num1+num2;
fprintf(fptr,"%d",sum);
fclose(fptr);
return 0;

}
