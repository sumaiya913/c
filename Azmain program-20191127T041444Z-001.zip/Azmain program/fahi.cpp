#include<bits/stdc++.h>
#include<stdio.h>
#include<math.h>
float func(float x)
{
    return 3*x-cos(x)-1;

}
int main()
{


    float a=0,b=1,c;
    if(func(a)*func(b)>=0)
        printf("invalid a and b selection\n");
        while((b-a)>=0.01)
        {
            c=((a*func(b))-(b*func(a)))/(func(b)-func(a));
            //cout<<"c="<<c<<end1;
            if(func(c)==0.0){


                printf("Root = %1f\n",c);
                break;
            }
            else if (func(c)*func(a) <= 0){

                printf("Root = %1f\n",c);
                b=c;
            }
            else{
                printf("Root = %1f\n",c);
                a=c;
            }
        }
}








