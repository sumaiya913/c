#include<stdio.h>
#include<math.h>

#define f(x) (2*x*x*x-3*x-6)
#define f1(x) (6*x*x-3)
//using namespace std;
int main()
{
 float a,b,c,e,x0;
 int i=0;
 printf("Input a and b:");
 scanf("%f %f",&a,&b);
 if(f(a)*f(b)>=0)
 {
 printf("Invalid Input\n");
 return 0;
 }
 x0=a;
 do
 {
 c=x0-(f(x0)/f1(x0));
 e=x0;
 x0=c;
 }while(fabs(c-e)>0.01);
 printf("Root is:%.2f",c);
}
