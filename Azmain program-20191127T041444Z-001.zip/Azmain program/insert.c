#include<stdio.h>
#include<string.h>
void main()
{
    int a[100],i,n,loc,c,item;
    printf("inter No. of elements\n");
    scanf("%d",&n);
    printf("Enter elements\n");
    for(i=1;i<=n;i++)
    {
        printf("\na[%d]=",i);
        scanf("%d",&a[i]);

    }
    for(;;)
    {

    if(n==100)
    {
        printf("overflow");
        return 0;

    }
    else{
            printf("Enter location:\n");
            scanf("%d",&loc);
            printf("\nEnter New value to insert:\n");
            scanf("%d",&item);
            for(i=n;i>=loc;i--)
            {
                a[i+1]=a[i];
            }
            a[loc]=item;
            n=n+1;
            printf("\nList after insert:\n");
            for(i=1;i<n;i++)
            {
                printf("\na[%d]: %d",i,a[i]);
            }

    }
    printf("Do u want to exit? enter 1 for yes 0 for No");
    scanf("%d",&c);
    if(c==1)
        return 0;

}
}
