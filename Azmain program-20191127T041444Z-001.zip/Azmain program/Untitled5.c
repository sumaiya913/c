
#include <stdio.h>

int main(){

    int vertex,edge,graph[30][30]={0},a,b,i,j;
    printf("Enter how many vertex : ");
    scanf("%d",&vertex);

    printf("Enter how many edges : ");
    scanf("%d",&edge);

    for(i = 1; i <= edge;i++){

        printf("Enter %d edge : ",i);
        scanf("%d %d",&a,&b);

        graph[a][1b] = 1;
    }

    printf("Showing the edges of the graph : \n");

    for(i = 1; i <= vertex;i++){

        for(j = 1; j <= vertex;j++){

            if(graph[i][j] == 1){
                printf("\nEdge detected : %d %d\n",i,j);
            }
        }
    }

}
