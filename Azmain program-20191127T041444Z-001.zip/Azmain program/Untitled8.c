#include<iostream>
2
#include <list>
3
using namespace std;
4

5
// a directed graph class
6
class DiGraph
7
{
8
    int V;    // No. of vertices
9

10
    // Pointer to an array containing adjacency lists
11
    list<int> *adjList;
12
public:
13
    DiGraph(int V);  // Constructor
14

15
    // add an edge from vertex v to w
16
    void addEdge(int v, int w);
17

18
    // BFS traversal sequence starting with s ->starting node
19
    void BFS(int s);
20
};
21

22
DiGraph::DiGraph(int V)
23
{
24
    this->V = V;
25
    adjList = new list<int>[V];
26
}
27
 void DiGraph::addEdge(int v, int w)
28
{
29
    adjList[v].push_back(w); // Add w to v�s list.
30
}
31

32
void DiGraph::BFS(int s)
33
{
34
    // initially none of the vertices is visited
35
    bool *visited = new bool[V];
36
    for(int i = 0; i < V; i++)
37
        visited[i] = false;
38

39
    // queue to hold BFS traversal sequence
40
    list<int> queue;
41

42
    // Mark the current node as visited and enqueue it
43
    visited[s] = true;
44
    queue.push_back(s);
45

46
    // iterator 'i' to get all adjacent vertices
47
    list<int>::iterator i;
48

49
    while(!queue.empty())
50
    {
51
        // dequeue the vertex
52
        s = queue.front();
53
        cout << s << " ";
54
        queue.pop_front();
55

56
        // get all adjacent vertices of popped vertex and process each if not already visited
57
        for (i = adjList[s].begin(); i != adjList[s].end(); ++i)
58
        {
59
            if (!visited[*i])
60
            {
61
                visited[*i] = true;
62
                queue.push_back(*i);
63
            }
64
        }
65
    }
66
}
67
// main program
68
int main()
69
{
70
    // create a graph
71
    DiGraph dg(5);
72
    dg.addEdge(0, 1);
73
    dg.addEdge(0, 2);
74
    dg.addEdge(0, 3);
75
    dg.addEdge(1, 2);
76
    dg.addEdge(2, 4);
77
    dg.addEdge(3, 3);
78
    dg.addEdge(4, 4);
79

80
    cout << "Breadth First Traversal for given graph (with 0 as starting node): "<<endl;
81
    dg.BFS(0);
82

83
    return 0;
84
}
